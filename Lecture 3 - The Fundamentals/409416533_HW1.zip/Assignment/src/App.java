public class App extends FuelCalc{
    public static void main(String[] args) throws Exception {
        System.out.println("Welcome to the fuel cost calcuator!");
        FuelCalc.Calc(args);
    }
}
