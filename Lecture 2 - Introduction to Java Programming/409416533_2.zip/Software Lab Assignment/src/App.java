public class App extends ReadImage{
    public static void main(String[] args) throws Exception {
        System.out.println("Welcome to use our image processing system!");
        ReadImage.processor(args);
    }
}
